//! Full 4v4 battles (2026-10-03, first version). Starting positions come from native/battle_starts.js: team preview resolved (my lead +
//! back two from a plan, their lead + back two from the replay model), turn 1 not yet played. Every turn both sides choose by the
//! one-turn matrix game of the 2v2 planner, with mid-game switching at one layer: each side's own matrix offers its own voluntary
//! switches but assumes the opponent stays in (my matrix = my moves+switches x their moves; theirs = my moves x their moves+switches).
//! The two matrices share the no-switch block, so each cell is computed once. Faint replacements: the replacement matrix game
//! (spot.rs resolve_switches). Value: the planner's position value (EG_VALUE; fitted on 2v2 endgames, so not calibrated for 4v4).
//!   champ battle <engine_data.json> <starts.jsonl> <outdir> [threads=3]
use crate::battle::*;
use crate::plan::*;
use crate::prng::{Mode, Prng};
use crate::sim::PChoice;
use crate::spot::{joint, label, resolve_switches, seed4};
use crate::state::*;
use serde_json::{json, Value};
use std::collections::{BTreeMap, HashMap};

const MAXTURN: usize = 25;
const STALL_MAXTURN: usize = 250;   // a game where neither side can deal damage (e.g. attack-less Indeedee-F vs Indeedee-F) plays on to PP exhaustion

/// can side s still deal damage: some living Pokemon has a damaging move with PP left, or has no PP left at all (Struggle)
fn can_damage(b: &Battle, s: u8) -> bool {
    b.sides[s as usize].pokemon.iter().filter(|p| !p.fainted).any(|p|
        p.move_slots.iter().any(|sl| sl.pp > 0 && b.dex.mv(sl.id).tmpl.category != "Status") || p.move_slots.iter().all(|sl| sl.pp <= 0))
}
fn ns() -> usize { std::env::var("BATTLE_NS").ok().and_then(|x| x.parse().ok()).unwrap_or(2) }

/// switch_slots / slot_decisions: active Pokemon that switched voluntarily / active Pokemon that could have (bench available, not trapped)
struct Out { v: f64, unsupported: Vec<String>, feats: Vec<Vec<f64>>, turns: usize, tr_turns: usize, tr_by: [bool; 3], switches: [usize; 2], slot_decisions: [usize; 2], switch_slots: [usize; 2], log: Vec<String> }

fn play(start: &Battle, cfg: &Cfg, mut rng: f64, key: u64, keep_log: bool) -> Out {
    let mut b = start.clone(); let mut turn = 1;
    let (mut tr_turns, mut tr_by, mut switches, mut log) = (0, [false; 3], [0usize; 2], vec![]);
    let (mut slot_decisions, mut switch_slots) = ([0usize; 2], [0usize; 2]);
    let mut uns: Vec<String> = vec![];
    let want_feats = std::env::var("BATTLE_FEATS").is_ok(); let mut fx: Vec<Vec<f64>> = vec![];
    while !b.ended && (turn <= MAXTURN || (turn <= STALL_MAXTURN && !can_damage(&b, 0) && !can_damage(&b, 1))) {
        let sw = std::env::var("BATTLE_NOSWITCH").is_err();   // BATTLE_NOSWITCH=1: control run, Pokemon only come in when something faints
        let msw = joint(&mut b, 0, sw); let tsw = joint(&mut b, 1, sw);
        if msw.is_empty() || tsw.is_empty() { break; }
        if want_feats { fx.push(feats(&mut b, cfg)); }   // position at the start of the turn, for refitting the value on 4v4 games
        let no_sw = |c: &[PChoice; 2]| !c.iter().any(|x| matches!(x, PChoice::Switch(_)));
        let mns: Vec<usize> = (0..msw.len()).filter(|i| no_sw(&msw[*i])).collect();
        let tns: Vec<usize> = (0..tsw.len()).filter(|j| no_sw(&tsw[*j])).collect();
        let cs: Vec<[u16; 4]> = (0..ns()).map(|k| seed4(key ^ ((turn as u64) << 40) ^ ((k as u64) << 52))).collect();
        let mut cache: HashMap<(usize, usize), f64> = HashMap::new();
        let mut cell = |i: usize, j: usize, b: &Battle| -> f64 {
            *cache.entry((i, j)).or_insert_with(|| {
                let mut s = 0.0;
                for c in &cs { let mut x = b.clone(); x.prng = Prng::gen5(*c); x.run_turn([msw[i], tsw[j]]); resolve_switches(&mut x, cfg, None); s += value(&mut x, cfg); }
                s / cs.len() as f64 })
        };
        // my matrix: all my options (moves + switches) vs their non-switch options
        let am: Vec<Vec<f64>> = (0..msw.len()).map(|i| tns.iter().map(|&j| cell(i, j, &b)).collect()).collect();
        // their matrix: my non-switch options vs all their options
        let at: Vec<Vec<f64>> = mns.iter().map(|&i| (0..tsw.len()).map(|j| cell(i, j, &b)).collect()).collect();
        let (mut x, _) = if tns.is_empty() { (vec![1.0 / msw.len() as f64; msw.len()], vec![]) } else { nash(&am, 400) };
        let (_, mut y) = if mns.is_empty() { (vec![], vec![1.0 / tsw.len() as f64; tsw.len()]) } else { nash(&at, 400) };
        // BATTLE_ANTICIPATE=1 (second pass): each side's matrix also gets the switches the other side actually plays (weight > 2% in its
        // one-layer mix), so a side plans against the opponent's real switches without searching every switch pair
        if std::env::var("BATTLE_ANTICIPATE").is_ok() {
            let isw: Vec<usize> = (0..msw.len()).filter(|i| !no_sw(&msw[*i]) && x[*i] > 0.02).collect();
            let jsw: Vec<usize> = (0..tsw.len()).filter(|j| !no_sw(&tsw[*j]) && y[*j] > 0.02).collect();
            if !jsw.is_empty() {
                let cols: Vec<usize> = tns.iter().copied().chain(jsw.iter().copied()).collect();
                let am2: Vec<Vec<f64>> = (0..msw.len()).map(|i| cols.iter().map(|&j| cell(i, j, &b)).collect()).collect();
                x = nash(&am2, 400).0;
            }
            if !isw.is_empty() {
                let rows: Vec<usize> = mns.iter().copied().chain(isw.iter().copied()).collect();
                let at2: Vec<Vec<f64>> = rows.iter().map(|&i| (0..tsw.len()).map(|j| cell(i, j, &b)).collect()).collect();
                y = nash(&at2, 400).1;
            }
        }
        let i = sample(&x, &mut rng); let j = sample(&y, &mut rng);
        if !no_sw(&msw[i]) { switches[0] += 1; } if !no_sw(&tsw[j]) { switches[1] += 1; }
        for (s, ch) in [(0u8, &msw[i]), (1u8, &tsw[j])] {
            let can = !crate::spot::bench(&b, s).is_empty();
            for k in 0..2 { if let Some(pi) = b.sides[s as usize].active[k] { let p = b.p((s, pi)); if !p.fainted && !p.trapped && can {
                slot_decisions[s as usize] += 1; if matches!(ch[k], PChoice::Switch(_)) { switch_slots[s as usize] += 1; } } } }
        }
        if keep_log { log.push(format!("T{} {} || {}  [{}+{} x {}+{}]", turn, label(&b, 0, &msw[i]), label(&b, 1, &tsw[j]), mns.len(), msw.len() - mns.len(), tns.len(), tsw.len() - tns.len())); }
        b.prng = Prng::gen5(seed4(key.wrapping_mul(31) ^ turn as u64));
        b.run_turn([msw[i], tsw[j]]);
        resolve_switches(&mut b, cfg, Some(&mut rng));
        for u in &b.unsupported { if !uns.contains(u) { uns.push(u.clone()); } }
        if find(&b.field.pseudo, "trickroom").is_some() { tr_turns += 1; if turn <= 3 { for k in (turn - 1)..3 { tr_by[k] = true; } } }
        turn += 1;
    }
    Out { v: value(&mut b, cfg), unsupported: uns, feats: fx, turns: turn - 1, tr_turns, tr_by, switches, slot_decisions, switch_slots, log }
}

pub fn main(args: &[String]) {
    let (dex, reg) = crate::turntest::load_all(&args[0]);
    let cfg: &'static Cfg = Box::leak(Box::new(load_cfg(&std::env::var("GRID_DIR").unwrap_or("../../mxtr".into()))));
    let threads: usize = args.get(3).and_then(|x| x.parse().ok()).unwrap_or(3);
    let keep_log = std::env::var("BATTLE_LOG").is_ok();
    let lines: Vec<String> = std::fs::read_to_string(&args[1]).unwrap().lines().map(|s| s.to_string()).collect();
    let dir = args[2].clone(); std::fs::create_dir_all(&dir).unwrap();
    let mut expect: BTreeMap<i64, usize> = BTreeMap::new();
    for l in &lines { let v: Value = serde_json::from_str(l).unwrap(); *expect.entry(v["job"].as_i64().unwrap()).or_default() += 1; }
    let next = std::sync::atomic::AtomicUsize::new(0);
    let pending: std::sync::Mutex<BTreeMap<i64, Vec<Value>>> = std::sync::Mutex::new(BTreeMap::new());
    let t0 = std::time::Instant::now();
    std::thread::scope(|sc| { for _ in 0..threads { sc.spawn(|| loop {
        let k = next.fetch_add(1, std::sync::atomic::Ordering::SeqCst); if k >= lines.len() { break; }
        let st: Value = serde_json::from_str(&lines[k]).unwrap();
        let job = st["job"].as_i64().unwrap();
        if std::path::Path::new(&format!("{}/{}.json", dir, job)).exists() { continue; }   // resume
        let b = crate::turntest::new_battle(dex, reg, &st["state"], Mode::Real);
        let g = st["g"].as_u64().unwrap();
        let key = ((job as u64) << 24) ^ (g << 4) ^ 0xBA77;
        let tg = std::time::Instant::now();
        let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| play(&b, cfg, st["rng"].as_f64().unwrap(), key, keep_log)));
        let row = match r {
            Ok(o) => json!({"g": g, "v": o.v, "turns": o.turns, "trTurns": o.tr_turns, "trBy": o.tr_by, "switches": o.switches, "slotDecisions": o.slot_decisions, "switchSlots": o.switch_slots, "unsupported": o.unsupported, "F": if o.feats.is_empty() { Value::Null } else { json!(o.feats) }, "ms": tg.elapsed().as_millis() as u64,
                            "log": if keep_log { json!(o.log) } else { Value::Null }}),
            Err(e) => json!({"g": g, "v": Value::Null, "error": e.downcast_ref::<String>().cloned().or(e.downcast_ref::<&str>().map(|s| s.to_string())).unwrap_or_default()}),
        };
        eprintln!("job {} game {}: {} ({} ms)", job, g, row["v"], tg.elapsed().as_millis());
        let done = { let mut pd = pending.lock().unwrap(); let e = pd.entry(job).or_default(); e.push(row); (e.len() == expect[&job]).then(|| pd.remove(&job).unwrap()) };
        if let Some(mut gs) = done {
            gs.sort_by_key(|x| x["g"].as_u64().unwrap());
            let vs: Vec<f64> = gs.iter().filter_map(|x| x["v"].as_f64()).collect();
            let feats: Vec<Value> = gs.iter().filter(|x| !x["F"].is_null()).map(|x| json!({"v": x["v"], "F": x["F"]})).collect();
            for x in gs.iter_mut() { x.as_object_mut().unwrap().remove("F"); }
            let mut out = json!({"job": job, "games": vs.len(), "v": if vs.is_empty() { Value::Null } else { json!(vs.iter().sum::<f64>() / vs.len() as f64) }, "vs": vs, "rows": gs});
            if !feats.is_empty() { out["feats"] = json!(feats); }
            if let Some(m) = st["meta"].as_object() { for (k, v) in m { out[k] = v.clone(); } }
            std::fs::write(format!("{}/{}.json", dir, job), out.to_string()).unwrap();
        }
    }); } });
    eprintln!("{} games in {:?}", lines.len(), t0.elapsed());
}
